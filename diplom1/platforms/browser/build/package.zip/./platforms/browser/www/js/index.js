$(document).ready(function() {
    var contentHeight = $("html").height() -  $("#mainmenu").height();

    $(".testt").css({
        height: contentHeight + 'px'
    });
});
    var sheldule = [];
     sheldule[0]={
        "day":"Понеділок",
        "lesson1": "Економетрія",
        "lesson2": "Теорія копіляції",
        "lesson3": "Корпоративні системи",
        "lesson4": "Програмування",
        "lesson5": "—"
    };

     sheldule[1]={
        "day":"Вівторок",
        "lesson1": "Інт. аналіз даних",
        "lesson2": "ППП в економіці",
        "lesson3": "—",
        "lesson4": "—",
        "lesson5": "—"
    };

     sheldule[2]={
        "day":"Середа",
        "lesson1": "—",
        "lesson2": "Економетрія",
        "lesson3": "Корпоративні системи",
        "lesson4": "Охорона праці",
        "lesson5": "—"
    };

     sheldule[3]={
        "day":"Четвер",
        "lesson1": "—",
        "lesson2": "Бази даних",
        "lesson3": "Теорія копіляції",
        "lesson4": "Теорія програмування",
        "lesson5": "—"
    };

     sheldule[4]={
        "day":"П'ятниця",
        "lesson1": "—",
        "lesson2": "Бази даних",
        "lesson3": "Нечітке моделювання",
        "lesson4": "Охорона праці",
        "lesson5": "—"
    };

     //console.log()





