
var app = {
    // Application Constructor
    initialize: function() {
        //alert("hello");
    }

};

app.initialize();